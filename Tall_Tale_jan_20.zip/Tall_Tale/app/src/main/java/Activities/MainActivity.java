package Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.tall_tale.R;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.button.MaterialButtonToggleGroup;

public class MainActivity extends AppCompatActivity {

    private BottomSheetBehavior bottomSheetBehavior;
    private TextView mTextViewState;
    //todo - replace this
    static int userHeight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CardView controlPanel = findViewById(R.id.control_panel);

        View bottomSheet = findViewById(R.id.bottom_sheet);

        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);

        //you can adjust peek height like this. Worth checking other methods?
        //mbottomSheetBehavior.setPeekHeight(10);

        /*
        //adjust textview to track progress
        mbottomSheetBehavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                switch (newState) {
                    case BottomSheetBehavior.STATE_COLLAPSED:
                        mTextViewState.setText("Collapsed");
                        break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        mTextViewState.setText("Dragging...");
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED:
                        mTextViewState.setText("Expanded");
                        break;
                    case BottomSheetBehavior.STATE_HIDDEN:
                        mTextViewState.setText("Hidden");
                        //stop sheet from hideing entirely
                        mbottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:
                        mTextViewState.setText("Settling...");
                        break;
                }
            }
         */

        //handle control panel visibility
        bottomSheetBehavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                switch (newState) {
                    //hide control panel
                    case BottomSheetBehavior.STATE_COLLAPSED:
                        controlPanel.setVisibility(View.GONE);
                        break;
                    //reveal control panel
                    case BottomSheetBehavior.STATE_EXPANDED:
                        controlPanel.setVisibility(View.VISIBLE);
                        break;
                }
            }
            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
            }
        });





        //TODO erase this stuff once you've handled progress bar functionality
        ProgressBar progressBar = findViewById(R.id.progress_bar);
        progressBar.setProgress(60);
        ConstraintLayout constraintLayout = findViewById(R.id.constraintLayout);
        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(constraintLayout);
        constraintSet.connect(R.id.user_current_card_view, ConstraintSet.TOP, R.id.milestone_60, ConstraintSet.TOP, 0);
        constraintSet.applyTo(constraintLayout);
    }

    //launch add activity
    public void launchAddBook(View v) {
        Intent i = new Intent(this, AddBook.class);

        startActivity(i);
    }
}
















