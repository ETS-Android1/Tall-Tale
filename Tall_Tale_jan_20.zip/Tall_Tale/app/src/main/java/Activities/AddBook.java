package Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.os.strictmode.CredentialProtectedWhileLockedViolation;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tall_tale.R;

import Controllers.Audio;
import Controllers.Digital;
import Controllers.Physical;
import Database.Book;

//this activity helps the user add a new book object to the database
//each form in this activity is styled in the layout file activity_add_book, so not additional fragments/popups are required for normal operation
public class AddBook extends AppCompatActivity {

    //references to forms
    CardView cardViewOne;
    CardView cardViewTwo;
    CardView cardViewThree;
    CardView cardViewFour;
    //track currently visible form
    int userProgress = 1;
    //Book object
    Book newBook;
    enum Type {PHYSICAL, DIGITAL, AUDIO}
    Type selectedType;
    //reference for views on second form, used for getting book thickness value
    TextView inputPrompt;
    EditText editCount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);

        //instantiate references
        cardViewOne = findViewById(R.id.form_one);
        cardViewTwo = findViewById(R.id.form_two);
        cardViewThree = findViewById(R.id.form_three);
        cardViewFour = findViewById(R.id.form_four);
        inputPrompt = findViewById(R.id.book_input_prompt);
        editCount = findViewById(R.id.edit_count);

        //set listeners for buttons in forms
        ImageButton formOneConfirm = findViewById(R.id.form_one_confirm);
        ImageButton formTwoConfirm = findViewById(R.id.form_two_confirm);
        ImageButton formThreeConfirm = findViewById(R.id.form_three_confirm);
        ImageButton formFourConfirm = findViewById(R.id.form_four_confirm);
        ImageButton formFourCancel = findViewById(R.id.form_four_cancel);

        //get radio input and progress to next form
        formOneConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get reference to radio group
                RadioGroup bookType = findViewById(R.id.book_type_radio);
                //validate that a selection has been made
                if(bookType.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(getApplicationContext(), "Well, this isn't gonna be easy.\n Please make a selection!", Toast.LENGTH_SHORT).show();
                    return;
                }

                //get reference to selected radio button
                RadioButton selectedButton = findViewById(bookType.getCheckedRadioButtonId());

                //identify button and perform appropriate action
                if(selectedButton == findViewById(R.id.radio_physical)) {
                    //notify activity of selection
                    selectedType = Type.PHYSICAL;
                    //change values for next form
                    physicalSelected();
                }
                else if (selectedButton == findViewById(R.id.radio_digital)) {
                    //notify activity of selection
                    selectedType = Type.DIGITAL;
                    //change values for next form
                    digitalSelected();
                }
                 else if (selectedButton == findViewById(R.id.radio_audio)) {
                    //notify activity of selection
                    selectedType = Type.AUDIO;
                    //change values for next form
                    audioSelected();
                }

                //progress user to next form
                nextForm();
            }
        });

        formTwoConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get user input and sanitize it
                if(isEmpty(editCount)) {
                    Toast.makeText(getApplicationContext(), "   Is the UI that bad?\nEnter a number, my guy", Toast.LENGTH_LONG).show();
                    return;
                }
                String unprocessedUserInput = editCount.getText().toString();
                int userInput = Integer.parseInt(removeSpecialCharacters(unprocessedUserInput));

                //invalidation for people insane enough to be reading a book like "Marcel Proust's elephantine Remembrance of Things Past" (a 9,609,000 word book)
                if(userInput > 1000000) {
                    Toast.makeText(getApplicationContext(), "    Wow! That's a long book.\nWaaaaay too long for this app.", Toast.LENGTH_LONG).show();
                }
               

                //progress user to next form
                nextForm();
            }
        });
    }



    //methods to change input prompt/edit text hint based on used book type selection
    public void physicalSelected() {
        inputPrompt.setText("How many pages does your book have?");
        editCount.setHint("250");
    }
    public void digitalSelected() {
        inputPrompt.setText("How many words does your book have?");
        editCount.setHint("70,000");
    }
    public void audioSelected() {
        inputPrompt.setText("How long is your book in minutes?");
        editCount.setHint("744");
    }

    //remove all special characters from user with a "number" keyboard
    public String removeSpecialCharacters(String string) {
        String sanitizedString = string.replace(",", "")
                .replace(".", "")
                .replace("-", "")
                .replace(" ", "");
        return sanitizedString;
    }

    //reset user progress onDestroy
    @Override
    protected void onDestroy() {
        super.onDestroy();
        userProgress = 1;
    }

    //this method takes the user to the next form, and if the user has visited them all, calls the launchHome() method
    public void nextForm() {
        switch (userProgress) {
            case 1:
                cardViewOne.setVisibility(View.GONE);
                cardViewTwo.setVisibility(View.VISIBLE);
                userProgress = 2;
                break;
            case 2:
                cardViewTwo.setVisibility(View.GONE);
                cardViewThree.setVisibility(View.VISIBLE);
                userProgress = 3;
                break;
            case 3:
                cardViewThree.setVisibility(View.GONE);
                cardViewFour.setVisibility(View.VISIBLE);
                userProgress = 4;
                break;
            case 4:
                userProgress = 1;
                launchHome();
                break;

        }
    }

    //check if edit text is empty
    public boolean isEmpty(EditText editText){
        return editText.getText().toString().trim().length() == 0;
    }

    //launch the home activity
    public void launchHome() {
        Intent i = new Intent(this, MainActivity.class);

        startActivity(i);
    }




}

