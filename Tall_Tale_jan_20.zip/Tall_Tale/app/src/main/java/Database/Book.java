package Database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import Controllers.Audio;
import Controllers.Digital;
import Controllers.Physical;

//SQLite table for Book objects
@Entity(tableName = "books")
public class Book {

    //average thickness for a page in a book
    public static final double PAGE_THICKNESS = 0.004;
    //average number of words on a typical novel page
    public static final int WORDS_TO_PAGE = 300;
    //average number of words spoken per minute in audiobook format
    public static final int WORDS_PER_MINUTE = 155;


    //determine book thickness for each type of Book, based on type
    //amount returned in fractions of an inch
    public int calculateThickness(Physical physicalBook) {
        int numPages = physicalBook.getPages();

        //get thickness of pages and round number
        int bookThickness = (int) Math.round(numPages * PAGE_THICKNESS);
        //make sure value is at least one
        if(bookThickness < 1) {
            bookThickness = 1;
        }

        return bookThickness;
    }
    public int calculateThickness(Digital digitalBook) {
        int numWords = digitalBook.getWords();
        //convert words to page count
        int numPages = numWords / WORDS_TO_PAGE;
        //convert page count to page thickness
        //get thickness of pages and round number
        int bookThickness = (int) Math.round(numPages * PAGE_THICKNESS);
        //make sure value is at least one
        if(bookThickness < 1) {
            bookThickness = 1;
        }

        return bookThickness;
    }
    public int calculateThickness(Audio audioBook) {
        int numMinutes = audioBook.getMinutes();
        //convert minutes of book to number of words
        int numWords = numMinutes * WORDS_PER_MINUTE;
        //convert words to page count
        int numPages = numWords / WORDS_TO_PAGE;
        //convert page count to page thickness
        //get thickness of pages and round number
        int bookThickness = (int) Math.round(numPages * PAGE_THICKNESS);
        //make sure value is at least one
        if(bookThickness < 1) {
            bookThickness = 1;
        }

        return bookThickness;
    }

    //constructor
    public Book(String title, String author, String startDate, String endDate, int thickness, String isCompleted) {
        this.title = title;
        this.author = author;
        this.startDate = startDate;
        this.endDate = endDate;
        this.thickness = thickness;
        this.isCompleted = isCompleted;
    }

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "title")
    private String title;

    @ColumnInfo(name = "author")
    private String author;

    //the date/time a user starts a book
    @ColumnInfo(name = "start_date")
    private String startDate;

    //the date/time a user ends a book
    @ColumnInfo(name = "end_date")
    private String endDate;

    //book thickness in centimeters
    @ColumnInfo(name = "thickness")
    private int thickness;

    //records if user has finished a book
    @ColumnInfo(name = "is_completed")
    private String isCompleted;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public int getThickness() {
        return thickness;
    }

    public void setThickness(int thickness) {
        this.thickness = thickness;
    }

    public String getIsCompleted() {
        return isCompleted;
    }

    public void setIsCompleted(String isCompleted) {
        this.isCompleted = isCompleted;
    }
}
