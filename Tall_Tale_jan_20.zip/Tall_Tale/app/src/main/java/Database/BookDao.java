package Database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

//Handle queries for Book Objects
@Dao
public interface BookDao {

    //return a list of all books
    @Query("SELECT * FROM books")
    List<Book> getAllBooks();

    //insert a new book object
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertBook(Book book);
}
