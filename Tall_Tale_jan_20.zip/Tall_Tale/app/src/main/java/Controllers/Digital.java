package Controllers;

import Database.Book;

//digital version of a book object
public class Digital extends Book {

    public Digital(String title, String author, String startDate, String endDate, int thickness, String isCompleted, int words) {
        super(title, author, startDate, endDate, thickness, isCompleted);
        this.words = words;
    }

    //amount of words in this digital book
    private int words;

    public int getWords() {
        return words;
    }

    public void setWords(int words) {
        this.words = words;
    }
}
