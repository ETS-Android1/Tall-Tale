package Controllers;

import Database.Book;

//audio version of a Book
public class Audio extends Book {

    public Audio(String title, String author, String startDate, String endDate, int thickness, String isCompleted, int minutes) {
        super(title, author, startDate, endDate, thickness, isCompleted);
        this.minutes = minutes;
    }

    private int minutes;

    //amount of minutes to this audio book
    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }
}
